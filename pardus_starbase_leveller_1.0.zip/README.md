# pardus_starbase_leveller
A chrome extension to assist in buying food and water from planets to keep bases at the correct ration of inputs.
